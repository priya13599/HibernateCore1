package com.nucleus.execution;


import java.util.ArrayList;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.nucleus.entity.Address;
import com.nucleus.entity.Student;

public class Main {
	
	
	public static void main(String[] args) {
		
		
		Configuration configuration = new Configuration();
		configuration.configure();
		SessionFactory factory = configuration.buildSessionFactory();
		Session session = factory.openSession();
		Transaction transaction = session.beginTransaction();
		Student student = new Student();
		student.setStudentname("Kavita");
		List<Address> address1 = new ArrayList<Address>();
		Address address = new Address();
		address.setCity("Lucknow");
		address.setCountry("India");
		address1.add(address);
		Address address2 = new Address();
		address2.setCity("Delhi");
		address2.setCountry("India");
		address1.add(address2);
		student.setAddress(address1);
		session.persist(student);
		/*
		List<String> address = new ArrayList<String>();
		address.add("Delhi");
		address.add("Lucknow");
		student.setAddress(address);
		session.persist(student);
		*/
		
		/*student.setStudentid(3);
		//student.setStudentname("InduLata");
		//Address address = new Address();
		//address.setCity("Ghaziabad");
		//address.setCountry("India");
		//student.setAddress(address);                                                                                  
		//session.persist(student);
		//session.saveOrUpdate(student);
		//session.delete(student);
*/		System.out.println("Data saved");
		transaction.commit();
		session.close();
		factory.close();
		
	}

}
