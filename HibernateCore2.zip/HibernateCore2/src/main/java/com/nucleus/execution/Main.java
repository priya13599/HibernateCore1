package com.nucleus.execution;



import java.util.ArrayList;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.nucleus.entity.Student;
import com.nucleus.entity.Subject;

public class Main {
	public static void main(String[] args) {
		Configuration configuration = new Configuration();
		configuration.configure();
		SessionFactory sessionfactory = configuration.buildSessionFactory();
		Session session = sessionfactory.openSession();
		Transaction transaction = session.beginTransaction();
		/*------One To One------*/
		/*Student student = new Student();
		student.setStudentid("123");
		student.setStudentname("Priya");
		Subject subject = new Subject();
		subject.setSubjectcode("111");
		subject.setSubjectname("Maths");
		student.setSubject(subject);
		session.persist(student);
		session.persist(subject);
		
		*/
		
		/*------One To Many------*/
		/*Student student = new Student();
		student.setStudentid("101");
		student.setStudentname("Shivika");
		Subject subject1 = new Subject();
	subject1.setSubjectcode("1001");
	subject1.setSubjectname("English");
	Subject subject2 = new Subject();
	subject2.setSubjectcode("1002");
	subject2.setSubjectname("DataStructures");
	List<Subject> subject3 = new ArrayList<Subject>();
	subject3.add(subject1);
	subject3.add(subject2);
	student.setSubjects(subject3);
	session.persist(subject1);
	session.persist(subject2);
	session.persist(student);*/
		
		
		/*------Many To Many------*/
		Student student = new Student();
		student.setStudentid("103");
		student.setStudentname("Kamal");
		Subject subject1 = new Subject();
	subject1.setSubjectcode("1001");
	subject1.setSubjectname("English");
	Subject subject2 = new Subject();
	subject2.setSubjectcode("1002");
	subject2.setSubjectname("DataStructures");
	List<Subject> subject3 = new ArrayList<Subject>();
	subject3.add(subject1);
	subject3.add(subject2);
	student.setSubjects(subject3);
	
	
	Student student1 = new Student();
	student1.setStudentid("102");
	student1.setStudentname("Disha");
	Subject subject4 = new Subject();
	subject4.setSubjectcode("1004");
	subject4.setSubjectname("Maths");
	Subject subject5 = new Subject();
	subject5.setSubjectcode("1003");
	subject5.setSubjectname("Compiler");
	List<Subject> subject6 = new ArrayList<Subject>();
	subject6.add(subject4);
	subject6.add(subject5);
	student.setSubjects(subject6);
	
	session.persist(student1);
	session.persist(subject1);
	session.persist(subject2);
	session.persist(subject4);
	session.persist(subject5);
	session.persist(student);
		
	transaction.commit();
	session.close();
	sessionfactory.close();
	
		
	}
}
